<h1 align="center"><b>𝗦𝗨𝗢𝗥𝗖𝗘 ELRASAM᷂᷂🦖</b></h1>

<p align="center">
    <br><b>يدعم تشغيل الموسيقي والفديو داخل المحادثات الصوتية</b><br>
</p>
<p align="center">
    <a href="https://www.python.org/" alt="اللغة المستخدمة"> <img src="https://img.shields.io/badge/Made%20with-Python-black.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>
</p>
## 🧪الحصول علي جلسة البيوجرام:
[![جلسة بيوجرام]<a href="https://t.me/ELRASAMbot"><img src="https://img.shields.io/badge/Dev%20ELRASAM-blue.svg?style=for-the-badge&logo=استخراج جلسه"></a> <a href="https://t.me/ELRASAMbot"><img src="https://img.shields.io/badge/استخراج جلسه-blue.svg?style=for-the-badge&logo=جلسه بيروجرام"></a> <a href="https://t.me/ELRASAMbot"><img src="https://img.shields.io/badge/جلسه بيروجرام -blue.svg?style=for-the-badge&logo=ELRASAM"></a>

## 𝗦𝗨𝗢𝗥𝗖𝗘 ELRASAM 
<p align="center">
  <img src="https://telegra.ph/file/b144db94dc0db0fd86526.jpg">
</p>

## ✨ المميزات
- يدعم تشغيل الفديو والموسيقي في المحادثة
- يدعم المحادثات المتعددة
- قائمه الانتظار مدعم
- تخطي وتوقف واستمرار مدعم
- يدعم تحميل فديو وصوت 
- يدعم البحث انلاين
- يدعم البحث المباشر من يوتيوب
- يدعم البث الحي من يوتيوب
- يدعم التحكم عن طريق الازرار
- يدعم التحكم بالصوت
- يدعم الدخول التلقائي للبوت المساعد
- تحديث مباشر

## 🛠 الاوامر:
| الاوامر | الوصف |
| ------ | ------ |
| `/mplay (اسم الاغنيه)` | تشغيل أغنية من يوتيوب |
| `/vplay (اسم الفديو)` | لتشغيل فديو من يوتيوب |
| `/vstream (لينك البث)` | لتشغيل بث حي فديو|
| `/pause` | لايقاف التشغيل ادمن فقط |
| `/resume` | لاستكمال التشغيل ادمن فقط |
| `/skip` | لتخطي الاغنيه ادمن فقط |
| `/stop` | لانهاء العرض ادمن فقط |
| `/vmute` | لكتم البوت المساعد |
| `/vunmute` | لالغاء كتم البوت المساعد |
| `/volume 1/200` | للتحكم في الصوت  |
| `/playlist` | لرؤية قائمة الاغاني |
| `/song (اسم الاغنيه)` | لتحميل اغنية |
| `/video (اسم الفديو)` | لتحميل فديو |
| `/userbotjoin` | لدعوة البوت المساعد |
| `/userbotleave` | لمغادرة البوت المساعد |
| `/leaveall` | خروج جميع المجموعات للمطور فقط |
| `/update` | تحديث البوت للمطور فقط |
| `/restart` | للمطور فقط اعاده تشغيل البوت |
| `/clean` | مسح جميع الملفات |
| `/rmd` | مسح جميع الملفات المحمله |


[![تشغيل](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/soursELRASAM/bonnU)






## قناة التحديثات والدعم¦🐰
<a href="https://t.me/E_L_R_A_S_A_M"><img src="https://img.shields.io/badge/Join-Group%20Support-blue.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/ELRASRM"><img src="https://img.shields.io/badge/Join-Updates%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>



مطــــــــور السورس ¦🦦
<a href="https://t.me/Mahmod777777"><img src="https://img.shields.io/badge/Dev%20ELRASAM-blue.svg?style=for-the-badge&logo=ELRASAM"></a> <a href="https://t.me/E_L_R_A_S_A_M"><img src="https://img.shields.io/badge/يـــــوزرا آلَرًسًــــــــآمِ-blue.svg?style=for-the-badge&logo=ELRASAM"></a> <a href="https://t.me/E_R_S_A_M1"><img src="https://img.shields.io/badge/ELRASAM2-blue.svg?style=for-the-badge&logo=ELRASAM"></a>
